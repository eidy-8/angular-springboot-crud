package com.eidy_8.server.dtos;

public class LoginResponse {

	private String token;
	
	public LoginResponse(String token) {
		this.token = token;
	}
	
	public String getToken() {
		return token;
	}
}
